package com.abc.pp.stringhandoff.tests;

import com.abc.pp.stringhandoff.*;

public interface StringHandoffFactory {
    StringHandoff create();
}
