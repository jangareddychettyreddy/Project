package com.abc.ds.action.string;

/**
 * Used to define an action to perform on String's.
 */
public interface StringDSAction {
    void perform(String item);
}
