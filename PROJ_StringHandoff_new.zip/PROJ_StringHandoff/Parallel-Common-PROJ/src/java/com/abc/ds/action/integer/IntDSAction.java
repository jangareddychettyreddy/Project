package com.abc.ds.action.integer;

/**
 * Used to define an action to perform on items of type int.
 */
public interface IntDSAction {
    void perform(int item);
}
